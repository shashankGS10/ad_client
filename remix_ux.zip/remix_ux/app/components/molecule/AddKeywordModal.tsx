import { useFetcher } from '@remix-run/react'
import { useEffect, useState } from 'react'

type Props = {
  campaignId: number
  onClose: () => void
}

export default function AddKeywordModal({ campaignId, onClose }: Props) {
  const fetcher = useFetcher()
  const [form, setForm] = useState({
    text: '',
    bid: 10,
    match_type: 'exact',
    state: 'enabled'
  })

  const update = (key: string, value: string | number) => {
    setForm(prev => ({ ...prev, [key]: value }))
  }

  useEffect(() => {
    if (fetcher.state === 'idle' && fetcher.data?.error === undefined) {
      onClose()
    }
  }, [fetcher.state])

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md shadow-md space-y-4">
        <h3 className="text-lg font-semibold">Add Keyword</h3>

        <fetcher.Form method="post" className="space-y-3">
          <input type="hidden" name="_action" value="add_keyword" />
          <input type="hidden" name="campaign_id" value={campaignId} /> {/* ✅ FIXED */}

          <div>
            <label className="block text-sm">Keyword</label>
            <input
              name="text"
              value={form.text}
              onChange={e => update('text', e.target.value)}
              required
              className="w-full border px-2 py-1 rounded"
            />
          </div>

          <div>
            <label className="block text-sm">Bid (₹)</label>
            <input
              name="bid"
              type="number"
              value={form.bid}
              onChange={e => update('bid', Number(e.target.value))}
              required
              className="w-full border px-2 py-1 rounded"
            />
          </div>

          <div>
            <label className="block text-sm">Match Type</label>
            <select
              name="match_type"
              value={form.match_type}
              onChange={e => update('match_type', e.target.value)}
              className="w-full border px-2 py-1 rounded"
            >
              <option value="exact">Exact</option>
              <option value="phrase">Phrase</option>
              <option value="broad">Broad</option>
            </select>
          </div>

          <div>
            <label className="block text-sm">State</label>
            <select
              name="state"
              value={form.state}
              onChange={e => update('state', e.target.value)}
              className="w-full border px-2 py-1 rounded"
            >
              <option value="enabled">Enabled</option>
              <option value="disabled">Disabled</option>
            </select>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={onClose} className="text-gray-600">
              Cancel
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Add
            </button>
          </div>
        </fetcher.Form>

        {fetcher.data?.error && (
          <p className="text-red-500 text-sm">{fetcher.data.error}</p>
        )}
      </div>
    </div>
  )
}
